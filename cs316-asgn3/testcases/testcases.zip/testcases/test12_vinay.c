void main(); main ()
{
  float b;
  b = e10;
}

