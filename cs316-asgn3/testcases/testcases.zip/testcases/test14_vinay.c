void main(); main ()
{
  int a;
  float b;
  b = 1e-4;
}

