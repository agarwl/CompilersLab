void main(); main ()
{
  float a;
  a = +3.0;
}

