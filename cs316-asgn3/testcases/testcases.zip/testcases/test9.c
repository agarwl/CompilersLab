void main();
main()
{
	int a;
	float b;
	a = -1;
	b = -;
}