void main(); main ()
{
  float a;
  a = 1 * 1;
}

