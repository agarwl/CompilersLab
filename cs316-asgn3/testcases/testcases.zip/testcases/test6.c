void main(); main()
{
	int a;
	int b;
	int c;
	int d;
	int e;
	int f;
	float g;
	g = 0;
	a = 0.0;
	b = 2;
	c = 3;
	f = a+b*c/d-e;
}