void main(); main()
{
}