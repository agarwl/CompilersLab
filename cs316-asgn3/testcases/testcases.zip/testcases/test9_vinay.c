void main(); main ()
{
  float a;
  a = 3.e1.;
}

