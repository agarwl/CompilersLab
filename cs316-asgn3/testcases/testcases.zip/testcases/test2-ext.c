float a;
int b;

void main(); main()
{
	int a;
	int b;
	float c;
	c = 0.4;
	a = 4;
	b = 4;
	a = b / a;
	a = b * a;
	a = b + a;
	a = b - a;
	b = -a;
}
