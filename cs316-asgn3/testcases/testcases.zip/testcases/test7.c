// Issue:
// The number of errors printed will depend on the implementation.
void main();
main()
{
	int a;
	float b;
	a = b+b*a;
}