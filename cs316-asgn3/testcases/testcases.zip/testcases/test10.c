void main();
main()
{
	int a;
	int b;
	a = (a*b) - (b+a*b-a);
}