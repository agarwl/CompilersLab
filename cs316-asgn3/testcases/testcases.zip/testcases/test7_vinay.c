void main(); main ()
{
  int a;
}

