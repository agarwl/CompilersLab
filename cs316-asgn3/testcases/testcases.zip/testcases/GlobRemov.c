void main();
int
Removing;

main()
{
	int a;
}
