void main(); main ()
{
  float b;
  b = .0e10;
}

