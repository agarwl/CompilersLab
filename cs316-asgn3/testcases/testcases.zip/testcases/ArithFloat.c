void main();
main()
{
	float a;
	float b;
	float c;
	a = 2.3;
	b = 3.4;
	c = a * b / a;
}
