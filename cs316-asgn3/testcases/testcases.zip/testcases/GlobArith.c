int a;
float b;
void main();
main()
{
	int c;
	float d;

	c = 2;
	d = 4.3;
	a = a * -c + a + a;
	d = -b * d / -d + b;
}
