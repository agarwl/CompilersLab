void main(); main()
{
	int a;
	float ;
}