void main(); main ()
{
  int a;
  float b;
  b = 10.;
}

