// Floating Point Literal Tests
// Unary Plus also tested
void main(); main()
{
	int a;
	float b;
	b = +.5E-2;
}