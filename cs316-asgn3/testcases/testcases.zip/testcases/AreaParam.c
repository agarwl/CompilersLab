float area;
float perimeter;
void main();
main()
{
	float x;
	float y;
	x = 3.0;
	y = 9.9;

	// Rectangle
	area = x * y;
	perimeter = 2.0 * (x + y);

	// Circle
	area = 22.0 * x * x / 7.0;
	perimeter = 2.0 * 22.0 * x /7.0;
}
