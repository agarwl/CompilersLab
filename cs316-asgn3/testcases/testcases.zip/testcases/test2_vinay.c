void main(); main()
{
	int a;
	int b;
	a = 0;
	b = 4;
	a = b*a*b*0*4;
	a = b*(a*b)*0*4;
	b = a-4;
	a = a--4;
}