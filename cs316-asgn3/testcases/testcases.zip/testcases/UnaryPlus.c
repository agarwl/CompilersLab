void main();
main()
{
	int a;
	int b;
	a = 2;
	b = +a;
	b = -+a;
	b = +-a;
}
