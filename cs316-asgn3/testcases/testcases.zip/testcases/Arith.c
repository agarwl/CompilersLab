void main();
main()
{
	int a;
	int f;
	int g;

	a = 1111111111;
	f = 2;
	g = 8;

	a = a + f - g;
}
